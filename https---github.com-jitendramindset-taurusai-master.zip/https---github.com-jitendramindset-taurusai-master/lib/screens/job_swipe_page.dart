import 'package:flutter/material.dart';

class JobSwipePage extends StatelessWidget {
  const JobSwipePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Job Swipe Page - Coming Soon'),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:taurusai/models/course.dart';
import 'package:taurusai/models/user.dart';
import 'package:taurusai/services/course_service.dart';

class CreateCourseScreen extends StatefulWidget {
  User user;

  CreateCourseScreen({required this.user});
  @override
  _CreateCourseScreenState createState() => _CreateCourseScreenState();
}

class _CreateCourseScreenState extends State<CreateCourseScreen> {
  final CourseService _courseService = CourseService();
  final _formKey = GlobalKey<FormState>();
  String title = '';
  String description = '';
  String instructor = '';
  String duration = '';
  String level = '';
  double price = 0.0;
  List<String> category = [];
  List<String> skill = [];
  String instructorUrl = '';
  String url = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Course'),
        backgroundColor: Colors.lightBlue[300],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Course Title'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter a course title' : null,
                onSaved: (value) => title = value!,
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration: InputDecoration(labelText: 'Description'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter a course description' : null,
                onSaved: (value) => description = value!,
                maxLines: 3,
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration: InputDecoration(labelText: 'Instructor'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter an instructor name' : null,
                onSaved: (value) => instructor = value!,
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration: InputDecoration(labelText: 'Duration'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter the course duration' : null,
                onSaved: (value) => duration = value!,
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration: InputDecoration(labelText: 'Level'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter the course level' : null,
                onSaved: (value) => level = value!,
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration: InputDecoration(labelText: 'Price'),
                validator: (value) =>
                    value!.isEmpty ? 'Please enter the course price' : null,
                onSaved: (value) => price = double.parse(value!),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration:
                    InputDecoration(labelText: 'Category (comma-separated)'),
                onSaved: (value) => category = value!.split(','),
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration:
                    InputDecoration(labelText: 'Skills (comma-separated)'),
                onSaved: (value) => skill = value!.split(','),
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration: InputDecoration(labelText: 'Instructor URL'),
                onSaved: (value) => instructorUrl = value!,
              ),
              SizedBox(height: 16),
              TextFormField(
                decoration: InputDecoration(labelText: 'Course URL'),
                onSaved: (value) => url = value!,
              ),
              SizedBox(height: 24),
              ElevatedButton(
                child: Text('Create Course'),
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    Course newCourse = Course(
                      id: '', // This will be set by Firestore
                      title: title,
                      description: description,
                      category: category,
                      skill: skill,
                      instructorUrl: instructorUrl,
                      topics: [], // Topics will be added later
                      duration: duration,
                      level: level,
                      price: price,
                      url: url,
                      status: 'Open',
                      createrId: widget.user.id,
                    );
                    try {
                      String courseId =
                          await CourseService().createCourse(newCourse);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text(
                                'Course created successfully with ID: $courseId')),
                      );
                      Navigator.pop(context);
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Error creating course: $e')),
                      );
                    }
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

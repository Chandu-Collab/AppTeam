package com.example.taurusai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
